# Remote Sensing Database R package 'RSDB'

---------------------------------------

### Install RSDB R Package
```R
if(!require("remotes")) install.packages("remotes")
remotes::install_github("environmentalinformatics-marburg/rsdb/r-package")
library(RSDB)
??RSDB
```

The RSDB R-package connects to a running RSDB server.
