# Remote Sensing Database R package

---------------------------------------

### Install R Package
```R
if(!require("remotes")) install.packages("remotes")
remotes::install_github("environmentalinformatics-marburg/rsdb/r-package")
library(RSDB)
??RSDB
```
